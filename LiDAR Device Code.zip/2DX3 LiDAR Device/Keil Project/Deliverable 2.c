// LiDAR Device C Program
// Maheer Huq
// 400508517

#include <stdint.h>
#include <stdio.h>
#include <math.h>
#include "tm4c1294ncpdt.h"
#include "PLL.h"
#include "uart.h"
#include "SysTick.h"
#include "VL53L1X_api.h"
#include "onboardLEDs.h"

// ====================
// FUNCTION PROTOTYPES
// ====================

// Port Initializations
void PortJ_Init(void);
void PortM_Init(void);
void PortH_Init(void);
void PortN_Init(void);
void PortF_Init(void);
void PortG_Init(void);

// Data Collection
void I2C_Init();
void VL53L1X_XSHUT();
void getData();

// Logic Functions
void SpinCW(void);
void SpinCCW(void);
void HomeMotor(void);

// ====================
// GLOBAL VARIABLES
// ====================

#define STEP_ANGLE 0.703125

// Trackers
volatile uint8_t flag = 0; // 0 = OFF, 1 = ON
volatile uint8_t direction = 1; // 1 = CW, 0 = CCW
volatile uint32_t delay = 1;
int status = 0;
float homePos = 0;
float currentPos = 0;
int data_ready_flag = 0;
char data_string[256]; 

// ToF Sensor
uint8_t sensorState = 0, i = 0;
uint16_t Distance;
uint8_t dataReady;
uint16_t dev = 0x29;	// Address of the ToF sensor as an I2C slave peripheral

// ====================
// I2C INITIALIZATION
// ====================

#define I2C_MCS_ACK             0x00000008  // Data Acknowledge Enable
#define I2C_MCS_DATACK          0x00000008  // Acknowledge Data
#define I2C_MCS_ADRACK          0x00000004  // Acknowledge Address
#define I2C_MCS_STOP            0x00000004  // Generate STOP
#define I2C_MCS_START           0x00000002  // Generate START
#define I2C_MCS_ERROR           0x00000002  // Error
#define I2C_MCS_RUN             0x00000001  // I2C Master Enable
#define I2C_MCS_BUSY            0x00000001  // I2C Busy
#define I2C_MCR_MFE             0x00000010  // I2C Master Function Enable

void I2C_Init(void){
  SYSCTL_RCGCI2C_R |= SYSCTL_RCGCI2C_R0;           													// activate I2C0
  SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R1;          												// activate port B
  while((SYSCTL_PRGPIO_R&0x0002) == 0){};																		// ready?
    GPIO_PORTB_AFSEL_R |= 0x0C;           																	// 3) enable alt funct on PB2,3; 0b00001100
    GPIO_PORTB_ODR_R |= 0x08;             																	// 4) enable open drain on PB3 only
    GPIO_PORTB_DEN_R |= 0x0C;             																	// 5) enable digital I/O on PB2,3																																		// 6) configure PB2,3 as I2C
		GPIO_PORTB_PCTL_R = (GPIO_PORTB_PCTL_R&0xFFFF00FF)+0x00002200;    			//TED
    I2C0_MCR_R = I2C_MCR_MFE;                      													// 9) master function enable
    I2C0_MTPR_R = 0b0000000000000101000000000111011;                       	// 8) configure for 100 kbps clock (added 8 clocks of glitch suppression ~50ns)
}

// ====================
// PORT INITIALIZATIONS
// ====================

void PortJ_Init(void){
	// Using PortJ pins (PJ0-PJ1) for digital input
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R8; // Enable clock for Port J
	while ((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R8) == 0) {} // Wait for clock to stabilize
	// PRGPIO == Peripheral Ready GPIO, indicates if port is ready for use
	// Ensures fully stabilized clock through a while loop
		
	GPIO_PORTJ_DIR_R &= ~0x03;   // Set PJ0, PJ1 as inputs
	GPIO_PORTJ_DEN_R |= 0x03;    // Enable digital I/O
	GPIO_PORTJ_PUR_R |= 0x03;    // Enable pull-up resistors
	GPIO_PORTJ_AMSEL_R &= ~0x03; // Disable analog
		
	return;
}

void PortM_Init(void){
	// Using PortM pins (PM0) for digital input
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R11; 
	while ((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R11) == 0) {} 
	
	GPIO_PORTM_DIR_R = 0x02;   ///// 00000....10 PM1 In, PM0 Out
	GPIO_PORTM_DEN_R |= 0x03;   
	GPIO_PORTM_AMSEL_R &= ~0x03; 

	return;
}

void PortH_Init(void){
	// Using PortH pins (PH0-PH3) for digital output
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R7;
	while ((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R7) == 0) {} 
	
	GPIO_PORTH_DIR_R |= 0x0F;     
	GPIO_PORTH_DEN_R |= 0x0F;    
	GPIO_PORTH_AMSEL_R &= ~0x0F;  
	GPIO_PORTH_AFSEL_R &= ~0x0F;  // Disable alternate functions on Port H

	return;
}

void PortN_Init(void){
	// Using PortN pins (PN0-PN1) for digital output
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R12; 
	while ((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R12) == 0) {} 

	GPIO_PORTN_DIR_R |= 0x03;    
	GPIO_PORTN_DEN_R |= 0x03;    
	GPIO_PORTN_AMSEL_R &= ~0x03; 
		
	return;
}

void PortF_Init(void){
	// Using PortF pins (PF0, PF4) for digital output
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R5;
	while ((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R5) == 0) {}

	GPIO_PORTF_DIR_R |= 0x11;     
	GPIO_PORTF_DEN_R |= 0x11;    
	GPIO_PORTF_AMSEL_R &= ~0x11; 
		
	return;
}

void PortG_Init(void){
	// Using PortG for digital output
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R6;              					 // activate clock for Port G
	while((SYSCTL_PRGPIO_R&SYSCTL_PRGPIO_R6) == 0){};   						 // allow time for clock to stabilize
	GPIO_PORTG_DIR_R &= 0x00;                                        // make PG0 in (HiZ)
  GPIO_PORTG_AFSEL_R &= ~0x01;                                     // disable alt funct on PG0
  GPIO_PORTG_DEN_R |= 0x01;                                        // enable digital I/O on PG0
																																	 // configure PG0 as GPIO
  //GPIO_PORTN_PCTL_R = (GPIO_PORTN_PCTL_R&0xFFFFFF00)+0x00000000;
  GPIO_PORTG_AMSEL_R &= ~0x01;                                     // disable analog functionality on PG0

	return;
}

void VL53L1X_XSHUT(void){
    GPIO_PORTG_DIR_R |= 0x01;                  // make PG0 out
    GPIO_PORTG_DATA_R &= 0b11111110;           //PG0 = 0
    FlashAllLEDs();
    SysTick_Wait10ms(10);
    GPIO_PORTG_DIR_R &= ~0x01;                 // make PG0 input (HiZ)
}

// ====================
// LOGIC FUNCTIONS
// ====================

// Handling spins in standalone functions due to their frequency of usage

void SpinCW(void){
	// FULL STEP
	GPIO_PORTH_DATA_R = 0b00000011;
	SysTick_Wait10ms(delay);            
	GPIO_PORTH_DATA_R = 0b00000110;            
	SysTick_Wait10ms(delay);
	GPIO_PORTH_DATA_R = 0b00001100;            
	SysTick_Wait10ms(delay);
	GPIO_PORTH_DATA_R = 0b00001001;            
	SysTick_Wait10ms(delay);
	currentPos += STEP_ANGLE;
}

void SpinCCW(void) {
	// FULL STEP
	GPIO_PORTH_DATA_R = 0b00001001;
	SysTick_Wait10ms(delay);          
	GPIO_PORTH_DATA_R = 0b00001100;            
	SysTick_Wait10ms(delay);
	GPIO_PORTH_DATA_R = 0b00000110;            
	SysTick_Wait10ms(delay);
	GPIO_PORTH_DATA_R = 0b00000011;            
	SysTick_Wait10ms(delay);
	currentPos -= STEP_ANGLE;
}

void getData()
{
  // Clear previous data
	data_string[0] = '\0';
	
	while(sensorState==0)
	{
		status = VL53L1X_BootState(dev, &sensorState);
		SysTick_Wait10ms(10);
	}

	status = VL53L1X_ClearInterrupt(dev);	
	status = VL53L1X_SensorInit(dev);
	Status_Check("SensorInit", status);
	status = VL53L1X_StartRanging(dev);   // Enable ranging

	// Get the Distance Measures 32 times	
	for(int i = 0; i < 512 ; i++)
	{
		if ((GPIO_PORTJ_DATA_R & 0x01) == 0) {
			SysTick_Wait10ms(25); // MUST debounce here or else it does not work
			return;  // Exit the function if the button is pressed
		}
		
		SpinCW(); // Rotate motor by 4 steps
		
		if(i % 16 == 0)  // Every 11.25 degrees
		{ 
			// Wait until ToF is ready for data collection
			while (dataReady == 0)
			{
				status = VL53L1X_CheckForDataReady(dev, &dataReady);
				VL53L1_WaitMs(dev, 5);	
			}
			
			dataReady = 0;
			status = VL53L1X_GetDistance(dev, &Distance);	// Read distance value from ToF	 		

			// Append to data string with space separator
			char temp[8]; // Temporary buffer enough to hold "65535 " (max uint16 and space)
			snprintf(temp, sizeof(temp), "%u ", Distance);
			strcat(data_string, temp);
			
			SysTick_Wait10ms(5);
		}

		// Print the resulted readings to UART
		if((GPIO_PORTJ_DATA_R & 0x01) == 0){
			SysTick_Wait10ms(25); // MUST debounce here or else it does not work
			GPIO_PORTN_DATA_R &= ~0x02;	
			return; // Check again while motor moving back
		}
	}
	
	// UART_printf(printf_buffer);
	VL53L1X_StopRanging(dev);
	data_ready_flag = 1; // WILL still return data if you stop while returning back
	
	// Need to return back to the home position
	for(int i = 0; i < 512; i++) {
		if((GPIO_PORTJ_DATA_R & 0x01) == 0) {
				SysTick_Wait10ms(25); // MUST debounce here or else it does not work
				GPIO_PORTN_DATA_R &= ~0x02;	
				return;  // Abort homing if button pressed
		}
		SpinCCW();
	}
	
	GPIO_PORTN_DATA_R &= ~0x02;	// Turn off start/stop indication LED (PN1 for me)
}

void HomeMotor(void) {
    int maxAttempts = 512; // Prevent infinite loops
    int attempts = 0;
    
    // Always rotate CCW until home position is reached
    while (fabs(currentPos - homePos) > 1.5 && attempts < maxAttempts) {
        SpinCCW(); // Force CCW rotation (no direction logic)
        attempts++;
        FlashLED2(1); // Visual feedback
			}    
		
    currentPos = homePos; // Reset to exact home position
    UART_printf("Homing Successful (CCW).\r\n");
}

// ====================
// MAIN LOGIC
// ====================

int main(void)
{	
	// Initializations
	PortJ_Init();
	PortN_Init();
	PortF_Init();
	PortH_Init();
	PortM_Init();
	PortG_Init();
	PLL_Init();  		// Set to 10MHz per individualized parameters
	SysTick_Init();
	I2C_Init();
	UART_Init();
	VL53L1X_XSHUT();
	flag = 0;
	
	while(1){
		if((GPIO_PORTJ_DATA_R & 0x01) == 0){ 					// PJ0 is low (active-low)	
			flag = !flag;
			GPIO_PORTN_DATA_R |= 0x02;						 	    // Turn on PN1 for measurement indication
			while ((GPIO_PORTJ_DATA_R & 0x01) == 0x01); // Waits for button release
		} 

		if ((GPIO_PORTJ_DATA_R & 0x02) == 0 && data_ready_flag) { // If data ready from getData()
				// Send complete data string
				UART_printf(data_string);
				UART_printf("\r\n");  // Terminate with newline
				FlashLED3(1); 				// Flash PF4 by specification
			
				data_ready_flag = 0;  // Reset flag
				while ((GPIO_PORTJ_DATA_R & 0x02) == 0);  // Wait for release
		}
		
		// BONUS: HOMING
		
		if ((GPIO_PORTM_DATA_R & 0x01) == 0 && data_ready_flag == 0) { 
				SysTick_Wait10ms(25); // Won't work without this
				HomeMotor(); 
				while ((GPIO_PORTM_DATA_R & 0x01) == 0); // Wait for release
		}
				
		if (flag){
			getData();
			flag = 0;
		}
		
		/// UNCOMMENT FOR PWM
//		while(1){
//			SysTick_Wait10ms(1);
//			GPIO_PORTM_DATA_R ^= 0x02;
//		}
		/////////////////////
		
	}
	
	return 0;
}